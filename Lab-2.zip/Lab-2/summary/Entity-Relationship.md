
1. Harry Potter:

- Friends with: Ron Weasley, Hermione Granger, Hagrid, Neville Longbottom
- Enemy of: Lord Voldemort, Draco Malfoy
- Protected by: Albus Dumbledore
- Related to: Lily Potter (mother), James Potter (father)
- Student of: Professor McGonagall, Professor Snape, Professor Flitwick, Professor Quirrell, Hagrid (Care of Magical Creatures)

2.	Ron Weasley:

- Friends with: Harry Potter, Hermione Granger, Neville Longbottom
- Sibling of: Ginny Weasley, Fred Weasley, George Weasley, Percy Weasley
- Student of: Professor McGonagall, Professor Snape, Professor Flitwick

3. Hermione Granger:

- Friends with: Harry Potter, Ron Weasley, Neville Longbottom
- Student of: Professor McGonagall, Professor Snape, Professor Flitwick

4. Lord Voldemort (Tom Riddle):

- Enemy of: Harry Potter, Albus Dumbledore
- Master of: Professor Quirrell
- Murderer of: Lily Potter, James Potter

5. Albus Dumbledore:

- Protector of: Harry Potter
- Headmaster of: Hogwarts students
- Colleague of: Professor McGonagall, Professor Snape, Hagrid, Professor Quirrell
- Friend of: Nicolas Flamel

6. Professor McGonagall:

- Teacher of: Harry Potter, Ron Weasley, Hermione Granger, Neville Longbottom
- Colleague of: Professor Snape, Professor Quirrell, Hagrid

7. Professor Snape:

- Teacher of: Harry Potter, Ron Weasley, Hermione Granger
- Colleague of: Professor McGonagall, Professor Quirrell, Hagrid
- Enemy of: James Potter
- Ally (in a way): Albus Dumbledore (due to his protection of Harry)

8. Professor Quirrell:

- Servant of: Lord Voldemort
- Teacher of: Harry Potter, Ron Weasley, Hermione Granger
- Colleague of: Professor Snape, Professor McGonagall, Hagrid

9. Hagrid:

- Friend of: Harry Potter, Ron Weasley, Hermione Granger
- Guardian of: Hogwarts grounds and creatures
- Colleague of: Professor McGonagall, Professor Snape, Professor Quirrell
- Owned by: Fluffy (three-headed dog)

10. Draco Malfoy:

- Rival of: Harry Potter, Ron Weasley, Hermione Granger
- Student of: Professor Snape

11. Neville Longbottom:

- Friends with: Harry Potter, Ron Weasley, Hermione Granger

12. Fred Weasley:

- Sibling of: Ron Weasley, George Weasley, Ginny Weasley, Percy Weasley
- Friend of: Lee Jordan
- Prankster/Teammate with: George Weasley
- Gryffindor House Member with: Harry Potter, Ron Weasley, Hermione Granger, Neville Longbottom

13. George Weasley:

- Sibling of: Ron Weasley, Fred Weasley, Ginny Weasley, Percy Weasley
- Friend of: Lee Jordan
- Prankster/Teammate with: Fred Weasley
- Gryffindor House Member with: Harry Potter, Ron Weasley, Hermione Granger, Neville Longbottom

14. Ginny Weasley:

- Sibling of: Ron Weasley, Fred Weasley, George Weasley, Percy Weasley
- Admires: Harry Potter (as seen briefly at King’s Cross)

15. Percy Weasley:

- Sibling of: Ron Weasley, Fred Weasley, George Weasley, Ginny Weasley
- Prefect over: Harry Potter, Ron Weasley, Hermione Granger
- Gryffindor House Member with: Harry Potter, Ron Weasley, Hermione Granger, Neville Longbottom

16. Nicolas Flamel:

- Friend of: Albus Dumbledore
- Keeper of: Sorcerer’s Stone (before it was destroyed)
- Spouse of: Perenelle Flamel

17. Lily Potter:

- Mother of: Harry Potter
- Spouse of: James Potter
- Murdered by: Lord Voldemort
- Sacrificed herself for: Harry Potter (providing him with magical protection)

18. James Potter:

- Father of: Harry Potter
- Spouse of: Lily Potter
- Murdered by: Lord Voldemort
- Rival of: Severus Snape

19. The Dursleys:

- Relatives of: Harry Potter
- Guardians of: Harry Potter (begrudgingly)
- Fear of: Harry’s magical abilities, Lord Voldemort (indirectly through Harry)
- Members:
- Uncle Vernon: Takes charge in reprimanding and controlling Harry’s actions
- Aunt Petunia: Enforces disdain toward magic and anything related to Lily Potter
- Dudley Dursley: Harry’s cousin; bullies Harry along with his parents

20. Fluffy:

- Owned by: Hagrid
- Guarding: The trapdoor to the Sorcerer’s Stone
- Subdued by: Music (revealed by Hagrid)

21. Firenze:

- Centaur who Rescued: Harry Potter in the Forbidden Forest
- Conflict with: Other centaurs (Bane), who disagree with his interference in human affairs

22. Bane:

- Centaur who Disapproves of: Firenze’s involvement with Harry Potter
- Centaur of: Forbidden Forest, skeptical of interference with “what is foretold”

23. Peeves the Poltergeist:

- Troublemaker for: Hogwarts students and staff
- Respects/Fears: The Bloody Baron
- Tricked by: Harry Potter (using the guise of the Bloody Baron)

24. The Bloody Baron:

- House Ghost of: Slytherin
- Feared by: Peeves the Poltergeist

25. Mrs. Norris:

- Cat companion of: Argus Filch (caretaker)
- Monitors: Hogwarts corridors, alerting Filch to rule-breakers

26. Argus Filch:

- Caretaker of: Hogwarts
- Loathes: Students, especially rule-breakers like Harry Potter
- Companion of: Mrs. Norris (his cat)

27. Lee Jordan:

- Friend of: Fred Weasley, George Weasley
- Gryffindor House Member with: Harry Potter, Ron Weasley, Hermione Granger, Neville Longbottom
